package dao;

import model.User;

public class UserDAO {

    public boolean saveUser(User user) {
        return true;
    }


    public User findUser(String username, String password) {
        if(username.equals("admin") && password.equals("123")) {
            User user = new User();
            user.setUsername(username);
            user.setRole("Patient");
            return user;
        }
        return null;
    }
}
