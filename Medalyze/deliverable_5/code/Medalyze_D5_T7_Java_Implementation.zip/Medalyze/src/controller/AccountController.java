package controller;

import dao.UserDAO;
import model.User;

public class AccountController {

    private UserDAO userDAO = new UserDAO();

    public boolean register(User user) {
        return userDAO.saveUser(user);
    }

    public User loginUser(String username, String password) {
        return userDAO.findUser(username, password);
    }
}
