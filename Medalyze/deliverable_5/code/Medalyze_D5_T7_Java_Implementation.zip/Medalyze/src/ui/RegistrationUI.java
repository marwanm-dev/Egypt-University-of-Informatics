package ui;

import controller.AccountController;
import model.User;

public class RegistrationUI {

    public void register() {

        User user = new User();
        user.setUsername("newUser");
        user.setPassword("password");
        user.setRole("Patient");

        AccountController controller = new AccountController();

        if (controller.register(user)) {
            System.out.println("User registered successfully.");
        } else {
            System.out.println("Registration failed.");
        }
    }
}