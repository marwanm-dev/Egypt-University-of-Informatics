package ui;

import controller.AccountController;
import model.User;

public class LoginUI {

    public void login() {
        AccountController controller = new AccountController();
        User user = controller.loginUser("admin", "123");

        if (user != null) {
            System.out.println("Login successful. Role: " + user.getRole());
        } else {
            System.out.println("Login failed.");
        }
    }
}