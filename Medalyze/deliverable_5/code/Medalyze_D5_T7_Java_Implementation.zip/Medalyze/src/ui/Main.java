package ui;

public class Main {

    public static void main(String[] args) {
        RegistrationUI reg = new RegistrationUI();
        reg.register();

        LoginUI login = new LoginUI();
        login.login();
    }
}
